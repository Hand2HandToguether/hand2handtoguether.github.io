export class Institucion_Educativa{
  id:number =0
  nombre_Institucion: string =""
  correo_Institucion: string =""
}
