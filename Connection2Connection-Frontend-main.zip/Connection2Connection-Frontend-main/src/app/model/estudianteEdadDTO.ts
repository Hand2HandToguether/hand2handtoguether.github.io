export interface estudianteEdadDTO {
    mayores: number;
    menores: number;
}