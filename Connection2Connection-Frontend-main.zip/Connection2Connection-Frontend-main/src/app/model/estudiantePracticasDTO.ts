export interface estudiantePracticasDTO {
    buscapracticas:number;
    nobuscapracticas:number;
}