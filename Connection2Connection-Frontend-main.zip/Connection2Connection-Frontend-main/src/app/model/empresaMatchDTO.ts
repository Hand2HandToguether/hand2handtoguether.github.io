export interface empresaMatchDTO {
  countestudiantesmatch: number;
  empresam: string;
}
