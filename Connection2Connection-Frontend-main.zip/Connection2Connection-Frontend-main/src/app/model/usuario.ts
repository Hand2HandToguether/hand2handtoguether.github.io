import { Rol } from "./rol"

export class Usuario{
  idUsuario:number =0
  dni_Usuario: number =0
  username:string =""
  nombre_Usuario:string =""
  correo_Usuario:string =""
  contrasena_Usuario:string =""
  rol:string =""
  enabled:boolean=true
}
