export interface institucionEstudianteDTO {
    institucion: String;
    countestudiantes:number;
}