export class Empresa{
  id:number =0
  nombre_Empresa: string =""
  descripcion_Empresa: string =""
  correo_Empresa:string =""
}
