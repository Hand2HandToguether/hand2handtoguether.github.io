export interface reclutadorMatchDTO {
  countestudiantesmatch: number;
  reclutadorm: string;
}
