export interface usuarioRolDTO {
  countusuarios: number;
  rol: string;
}
