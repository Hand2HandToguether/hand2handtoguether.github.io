import { Usuario } from "./usuario"

export class Rol{
  id:number =0
  rol: String =""
  usuario: Usuario = new Usuario()
}
