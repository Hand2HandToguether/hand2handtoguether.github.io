export interface estudianteSemestreDTO {
    countestudiante: number;
    semestree:number;
}