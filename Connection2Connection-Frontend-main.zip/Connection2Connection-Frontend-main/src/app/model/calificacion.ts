export class Calificacion{
  id:number =0
  idEstudiante_Calificacion: number =0
  calificacion_Calificacion: number =0
}
