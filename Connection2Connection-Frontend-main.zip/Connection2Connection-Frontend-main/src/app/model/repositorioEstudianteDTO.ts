export interface repositorioEstudianteDTO {
  nameEstudiante: string;
  correoEstudiante: string;
  edadEstudiante: number;
  practicanteEstudiante: boolean;
  repositorioCount: number;
}
