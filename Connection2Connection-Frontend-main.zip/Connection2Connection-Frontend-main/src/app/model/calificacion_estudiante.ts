import { Estudiante } from "./estudiante"
import { Calificacion } from "./calificacion"

export class Calificacion_Estudiante{
  id:number =0
  estudiante: Estudiante = new Estudiante()
  calificacion: Calificacion = new Calificacion()
}
