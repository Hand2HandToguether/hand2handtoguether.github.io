export interface estudianteEdadPromedioDTO {
    promedioedad: number;
    countestudiantes: number;
}