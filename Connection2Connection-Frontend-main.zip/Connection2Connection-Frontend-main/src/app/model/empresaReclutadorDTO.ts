export interface empresaReclutadorDTO {
  nameEmpresa: string;
  reclutadorCount: number;
}
