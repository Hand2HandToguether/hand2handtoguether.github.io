export class Requisito{
  id:number;
  descripcion_Requisito: string;
}
