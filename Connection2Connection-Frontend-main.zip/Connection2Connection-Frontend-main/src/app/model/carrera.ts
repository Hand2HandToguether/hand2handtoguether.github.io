export class Carrera{
  id:number =0
  nombre_Carrera: string =""
}
