import { Carrera } from "./carrera"
import { Estudiante } from "./estudiante"

export class Carreras_Estudiante{
  id:number =0
  estudiante: Estudiante = new Estudiante()
  carrera: Carrera = new Carrera()
}
